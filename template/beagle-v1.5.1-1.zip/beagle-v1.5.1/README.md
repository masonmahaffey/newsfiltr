# Beagle

Thank you for support our work, Beagle is an HTML/CSS/JS admin template based on the famous Bootstrap framework, made it with love in every pixel.

## Current Version: 1.5.1

## Getting Started

This project requires Node.js to work properly, [Install NodeJs here](https://nodejs.org/) if you don't have it already.

Follow the next steps to get started with the template:

1. Install node dependencies with `npm install` command
2. Run the local server with `npm start` command
3. Open your browser and go to http://localhost:8080

## Generate a distribution
To generate a new distribution just run `npm run dist` command, this will create the `dist` folder in project's root path.

## License
Copyright Foxy Themes
